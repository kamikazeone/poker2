<?php

//MASUKAN UID MILIK KALIAN
$uid = "xxxxxxxxxxx";

//MASUKAN CRED MILIK KALIAN!!
$cred = "xxxxxxxxxx";

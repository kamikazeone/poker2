<?php

//MASUKAN UID MILIK KALIAN
$uid = "xxxxxxx";

//MASUKAN CRED MILIK KALIAN!!
$cred = "xxxxxxx";
